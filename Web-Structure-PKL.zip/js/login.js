/**
 * Sample JavaScript code for youtube.activities.list
 * See instructions for running APIs Explorer code samples locally:
 * https://developers.google.com/explorer-help/guides/code_samples#javascript
 */

function authenticate() {

    return gapi.auth2.getAuthInstance()
        .signIn({
            scope: 'https://www.googleapis.com/auth/youtube.readonly  https://www.googleapis.com/auth/youtube.force-ssl'
        })
        .then(function loadClient() {

            console.log('Sign-in successful');

            const signOutContent = document.getElementById('signOutContent')
            const signout = document.getElementById('signout')

            signOutContent.style.display = 'none'
            signout.innerHTML = `
                <a class="nav-link collapsed" style="cursor: pointer;" onclick="signOut()">
                    <i class="fas fa-fw fa-power-off text-danger"></i>
                    <span>Sign out</span>
                </a>
            `;

            gapi.client.setApiKey('AIzaSyBM4ysi8MDVOMEGHkvEXdQbTayLJa3jEdU');
            return gapi.client.load('https://www.googleapis.com/discovery/v1/apis/youtube/v3/rest')
                .then(function () {
                    console.log('GAPI client loaded for API');
                },
                function (err) {
                    console.error('Error loading GAPI client for API', err);
                });

        },
            function (err) {
                console.error('Error signing in', err);
            });

}

// Make sure the client is loaded and sign-in is complete before calling this method.
function execute() {

    return gapi.client.youtube.activities.list({

            "part": "snippet,contentDetails",
            "maxResults": 3,
            "mine": true

        })
        .then(function (response) {

                // Handle the results here (response.result has the parsed body).
                console.log('Response', response);
                const dataExecute = response.result.items

                if (dataExecute) {

                    const videoContainer = document.getElementById('videoContainer')

                    let output;'<small class="text-muted"><i>Max Results Limit is 3 video</i></small>'

                    // Loop the video sources
                    dataExecute.forEach(video => {

                        const thisVideoId = video.contentDetails.upload.videoId
                        const videoTitle = video.snippet.title

                        output += `
                            <div class="card mb-3" style="max-width: auto">
                                <div class="row no-gutters">
                                    <div class="col-md-4">
                                        <iframe style="width: 100%;" class="card-img" src="https://www.youtube.com/embed/${thisVideoId}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <h5 class="card-title">${videoTitle}</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;

                    });

                    // Output videos
                    videoContainer.innerHTML = output

                } else {

                    videoContainer.innerHTML = `
                        <h1>No Uploaded Video!</h1>
                    `

                }

            },
            function (err) {
                console.error("Execute error", err);
            });

};

function execute1() {

    return gapi.client.youtube.channels.list({

            "part": "snippet,contentDetails,statistics",
            "mine": true

        })
        .then(function (response) {

                // Handle the results here (response.result has the parsed body).
                console.log("Response", response);
                const dataExecute1 = response.result.items[0]
                const statsContainer = document.getElementById('statsContainer')

                // User Data
                const dashboard = document.getElementById('dashboard')
                const username = document.getElementById('username')
                const userImg = document.getElementById('userImg')

                dashboard.innerHTML = dataExecute1.snippet.title
                username.innerHTML = dataExecute1.snippet.title
                userImg.setAttribute('src', dataExecute1.snippet.thumbnails.default.url)

                // Channel Statistics
                let output = '<h3 class="text-danger">Youtube<small class="text-muted">Channel Data</small></h3>'

                output += `

                    <div class="card border border-danger">
                        <div class="card-body">
                            Channel Title : <br> <strong><div>${dataExecute1.snippet.title}</div></strong>
                        </div>
                        <div class="card-body">
                            Id Channel : <br> <div>${dataExecute1.id}</div>
                        </div>
                        <div class="card-body">
                            Subscribers : <br> <div>${dataExecute1.statistics.subscriberCount}</div> subscribers
                        </div>
                        <div class="card-body">
                            Channel Views : <br> <div>${dataExecute1.statistics.viewCount}</div> views
                        </div>
                        <div class="card-body">
                            Channel Videos : <br> <div>${dataExecute1.statistics.videoCount}</div> videos
                        </div>
                        <div class="card-body">
                            Channel Description : <br> <div>${dataExecute1.snippet.description}</div>
                        </div>
                    </div>

                `;

                statsContainer.innerHTML = output


            },
            function (err) {
                console.error("Execute error", err);
            });

};

function execute2() {
    return gapi.client.youtube.commentThreads.list({

            'part': 'snippet,replies',
            'channelId': 'UCX6BKVww7byip0BhpCjiVTg',
            'order': 'relevance',
            'maxResults': 10

        })
        .then(function (response) {
                // Handle the results here (response.result has the parsed body).
                console.log('Response', response);
            },
            function (err) {
                console.error('Execute error', err);
            });
}

// Load OAuth 2.0 Client
gapi.load('client:auth2', function () {
    gapi.auth2.init({
        client_id: '359895804402-dtknedm9b8pa3q4abkb48ncm9246s5hd.apps.googleusercontent.com'
    });
});