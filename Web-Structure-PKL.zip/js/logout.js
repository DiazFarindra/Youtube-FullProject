function signOut() {

    const auth2 = gapi.auth2.getAuthInstance();

    auth2.signOut().then(function () {

        // const signinContent1 = document.getElementById('signinContent1')
        // const signinContent2 = document.getElementById('signinContent2')
        // const signOutContent = document.getElementById('signOutContent')

        // signinContent1.style.display = 'none'
        // signinContent2.style.display = 'none'
        // signOutContent.style.display = 'block'

        document.location.reload(true)

        console.log('User signed out.');

    });

}
// signOut()